# HumanEase.ai  AI Content Authenticity Detector & Humaniser

A full-stack web application that detects AI-generated text and humanizes it to sound more natural and authentic. Built with FastAPI backend and vanilla JavaScript frontend.

---

##  Features

- **AI Detection**: Analyze text or upload PDF files to detect if content is AI-generated
- **Authenticity Meter**: Real-time scoring (0-100%) showing how AI-like the text is
- **Text Humanization**: Convert AI-generated text to natural, human-like writing
- **Multiple Tones**: Choose from Casual, Formal, or Friendly humanization styles
- **PDF Support**: Extract and analyze text directly from PDF documents
- **Live Results**: See before/after comparisons with AI detection scores

---

##  Architecture & How It Works

### Detection Logic (Hybrid Approach)

The AI detection system uses a **hybrid approach** combining machine learning and rule-based heuristics:

#### 1. Machine Learning Component (20% weight)
- **Algorithm**: Logistic Regression with TF-IDF vectorization
- **Features**: Unigrams, bigrams, and trigrams (up to 5000 features)
- **Training Data**: AI-generated vs human-written text samples
- **Limitation**: Small dataset (26 samples), so ML has lower weight

#### 2. Rule-Based Heuristics (80% weight)
The system analyzes multiple text characteristics:

**AI Indicators (increase score):**
- AI-typical phrases: "moreover", "furthermore", "paradigm shift", "cutting-edge", "leverage", "optimize", etc. (+10% each)
- Sentence uniformity: AI writes more consistent sentence lengths (+10%)
- Long sentences: Average sentence length > 20 words (+10%)
- Formal vocabulary: "however", "therefore", "nevertheless" (+5% each)

**Human Indicators (decrease score):**
- Casual language: "lol", "tbh", "idk", "gonna", "wanna" (-15% each)
- Contractions: "can't", "don't", "I'll", "won't" (-10%)
- Personal pronouns: High usage of "I", "my", "me" (-10%)

**Final Score Calculation:**
```
final_score = (0.2  ml_score) + (0.8  heuristic_score)
```

**Score Interpretation:**
- 0-40%: Human-written text
- 41-69%: Mixed/Uncertain (possibly edited AI or formal human writing)
- 70-100%: AI-generated text

### Humanization Logic

Uses Google Gemini 2.5 Flash model with carefully crafted prompts:

1. **Prompt Engineering**: 
   - Explicit blacklist of 20+ AI phrases to avoid
   - Tone-specific instructions (Casual, Formal, Friendly)
   - Rules for natural writing (contractions, varied sentences, personal touches)

2. **Model Configuration**:
   - Temperature: 0.9 (higher creativity and variation)
   - Top-P: 0.95 (nucleus sampling for diversity)
   - Top-K: 40 (limits vocabulary to more natural words)

3. **Process Flow**:
   ```
   AI Text  Gemini API  Humanized Text  Re-scored  Display Results
   ```

---

##  Requirements & Dependencies

### Core Backend
- **FastAPI**: Modern web framework for building APIs
- **Uvicorn**: ASGI server for running FastAPI
- **Jinja2**: Template engine for HTML rendering
- **python-multipart**: Form data parsing for file uploads

### Machine Learning
- **pandas**: Data manipulation and analysis
- **numpy**: Numerical computing
- **scikit-learn**: ML algorithms (Logistic Regression, TF-IDF)
- **joblib**: Model serialization/deserialization

### NLP Libraries
- **nltk**: Natural Language Toolkit (for future enhancements)
- **spacy**: Advanced NLP (for future enhancements)

### Document Processing
- **PyMuPDF (pymupdf)**: PDF text extraction

### AI Integration
- **openai**: OpenAI API client (for future GPT integration)
- **google-generativeai**: Google Gemini API for text humanization
- **python-dotenv**: Environment variable management

---

##  Setup & Installation

### Prerequisites
- Python 3.10 or higher
- Google Gemini API key

### Installation Steps

1. **Create and activate virtual environment**
   ```bash
   python -m venv .venv
   .venv\Scripts\activate
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Configure environment variables**
   
   Edit `.env` file in the root directory:
   ```env
   GEMINI_API_KEY=your_api_key_here
   ```

4. **Run the application**
   ```bash
   uvicorn backend.app:app --reload
   ```

5. **Access the application**
   
   Open browser at: `http://127.0.0.1:8000`

---

##  Future Improvements

### Short-term
1. Expand training dataset (10,000+ samples)
2. Implement transformer-based models (BERT, RoBERTa)
3. Multi-language support
4. Batch processing

### Medium-term
5. User accounts & history
6. REST API endpoints
7. Advanced analytics & reports
8. Browser extension

### Long-term
9. Fine-tuned humanization models
10. Domain-specific detection
11. Real-time collaboration
12. Mobile application
13. Integration ecosystem

---

##  Known Limitations

1. Small training dataset (26 samples)
2. English only
3. API rate limits (free tier)
4. Complex PDF layouts may cause issues
5. Heuristics may misclassify formal human writing

---

**Built with  using FastAPI, Gemini AI, and Machine Learning**
