from pathlib import Path
from typing import Dict

import joblib
import numpy as np

from utils.preprocessing import clean_text

# Paths
BASE_DIR = Path(__file__).resolve().parent
MODELS_DIR = BASE_DIR / "models"

CLASSIFIER_PATH = MODELS_DIR / "classifier.pkl"
VECTORIZER_PATH = MODELS_DIR / "vectorizer.pkl"

# Load model & vectorizer when module imports
_classifier = None
_vectorizer = None

def _load_models():
    global _classifier, _vectorizer
    if _classifier is None or _vectorizer is None:
        try:
            _vectorizer = joblib.load(VECTORIZER_PATH)
            _classifier = joblib.load(CLASSIFIER_PATH)
            print("[DETECTOR] Models loaded successfully.")
        except Exception as e:
            print(f"[DETECTOR] Error loading models: {e}")
            _classifier = None
            _vectorizer = None

def _heuristic_score(text: str) -> float:
    """
    Rule-based heuristic scoring when ML model is unreliable.
    Returns AI probability (0-1)
    """
    import re
    from collections import Counter
    
    words = text.lower().split()
    sentences = [s.strip() for s in re.split(r'[.!?]+', text) if s.strip()]
    
    if len(words) < 10:
        return 0.5  # Too short to judge
    
    # Start with base score
    score = 50.0  # Start at 50%
    
    # 1. AI-typical phrases (STRONGEST indicator - each adds 15%)
    ai_phrases = [
        'it is important to note', 'it is worth noting', 'in conclusion',
        'furthermore', 'moreover', 'additionally', 'consequently',
        'it should be noted', 'one must consider', 'delve into',
        'in today\'s world', 'in this day and age', 'cutting-edge',
        'game-changer', 'revolutionize', 'paradigm shift', 'leverage',
        'facilitate', 'implementation', 'comprehensive', 'robust',
        'innovative', 'optimize', 'enhance', 'streamline', 'utilize',
        'it is essential', 'it is crucial', 'landscape', 'emerged as',
        'transformative', 'unprecedented'
    ]
    phrase_matches = sum(1 for phrase in ai_phrases if phrase in text.lower())
    score += phrase_matches * 10  # Each phrase adds 10%
    
    # 2. Casual language (STRONG human indicator - each subtracts 15%)
    casual_markers = ['lol', 'omg', 'wtf', 'yeah', 'nah', 'gonna', 'wanna', 
                      'kinda', 'sorta', 'idk', 'tbh', 'imo', 'btw', 'haha', 'hehe']
    casual_count = sum(1 for marker in casual_markers if marker in text.lower())
    score -= casual_count * 15
    
    # 3. Contractions (human indicator - subtract 10%)
    contractions = len(re.findall(r"n't|'ll|'ve|'re|'m|'d", text))
    if contractions >= 3:
        score -= 10
    
    # 4. Personal pronouns (human indicator)
    personal_pronouns = len(re.findall(r'\b(i|my|me|mine|myself)\b', text.lower()))
    pronoun_ratio = personal_pronouns / len(words) if len(words) > 0 else 0
    if pronoun_ratio > 0.03:
        score -= 10
    
    # 5. Sentence uniformity (AI indicator)
    if len(sentences) >= 3:
        sent_lengths = [len(s.split()) for s in sentences]
        avg_len = np.mean(sent_lengths)
        std_len = np.std(sent_lengths)
        if avg_len > 0:
            coefficient_of_variation = std_len / avg_len
            if coefficient_of_variation < 0.3:  # Very uniform
                score += 10
    
    # 6. Long average sentence length (AI indicator)
    if len(sentences) > 0:
        avg_sent_len = np.mean([len(s.split()) for s in sentences])
        if avg_sent_len > 20:
            score += 10
        elif avg_sent_len > 15:
            score += 5
    
    # 7. Formal vocabulary (AI indicator)
    formal_words = ['however', 'therefore', 'thus', 'hence', 'whereas', 'thereby', 
                    'nonetheless', 'nevertheless', 'notwithstanding']
    formal_count = sum(1 for word in formal_words if word in text.lower())
    score += formal_count * 5
    
    # Clamp to 0-100 range and convert to 0-1
    score = max(0.0, min(100.0, score))
    return score / 100.0

def predict_score(text: str) -> Dict:
    """
    Returns:
        {
          "score": float (0-100),
          "label": "Human" | "AI-generated" | "Uncertain",
          "explanation": str
        }
    """
    _load_models()

    if not text or not text.strip():
        return {
            "score": 0.0,
            "label": "Uncertain",
            "explanation": "No text provided for analysis."
        }

    # Try ML model first, but use heuristics as fallback or blending
    ml_score = None
    if _classifier is not None and _vectorizer is not None:
        try:
            cleaned = clean_text(text)
            X = _vectorizer.transform([cleaned])
            proba = _classifier.predict_proba(X)[0]
            ml_score = float(proba[1])  # AI probability
        except Exception as e:
            print(f"[DETECTOR] ML prediction failed: {e}")
            ml_score = None
    
    # Get heuristic score
    heuristic_score = _heuristic_score(text)
    
    # Blend scores if ML is available, otherwise use pure heuristic
    if ml_score is not None:
        # Blend 20% ML + 80% heuristic (ML model is very weak with limited training data)
        ai_prob = 0.2 * ml_score + 0.8 * heuristic_score
    else:
        ai_prob = heuristic_score
    
    score = round(ai_prob * 100, 2)

    if score >= 70:
        label = "AI-generated"
        explanation = "Text shows strong patterns typical of AI writing (uniform style, repetitive structure, formal phrasing)."
    elif score <= 40:
        label = "Human"
        explanation = "Text appears more natural and varied, with human characteristics like casual language or irregular patterns."
    else:
        label = "Mixed/Uncertain"
        explanation = "Text contains a mixture of patterns; it may be edited AI content or human writing with formal structure."

    return {
        "score": score,
        "label": label,
        "explanation": explanation
    }
