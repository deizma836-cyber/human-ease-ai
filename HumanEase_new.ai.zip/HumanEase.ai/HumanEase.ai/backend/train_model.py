from pathlib import Path

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score
import joblib

from .utils.preprocessing import clean_text

ROOT_DIR = Path(__file__).resolve().parent.parent  # HumanEase/
DATA_DIR = ROOT_DIR / "data"
MODELS_DIR = Path(__file__).resolve().parent / "models"
MODELS_DIR.mkdir(exist_ok=True)

AI_FILE = DATA_DIR / "ai_text.csv"
HUMAN_FILE = DATA_DIR / "human_text.csv"

def load_and_label_data():
    ai_df = pd.read_csv(AI_FILE, header=None, names=["text"], engine="python", on_bad_lines="skip")
    human_df = pd.read_csv(HUMAN_FILE, header=None, names=["text"], engine="python", on_bad_lines="skip")

    ai_df["label"] = 1  # AI
    human_df["label"] = 0  # Human

    df = pd.concat([ai_df, human_df], ignore_index=True)
    
    # Drop null values and filter out very short texts
    df = df.dropna(subset=["text"])
    df = df[df["text"].notna()]
    df["text"] = df["text"].astype(str)
    df = df[df["text"].str.len() > 20]  # Filter out very short fragments
    
    df["clean_text"] = df["text"].apply(clean_text)
    
    print(f"[TRAIN_MODEL] Loaded {len(df)} samples")
    print(f"[TRAIN_MODEL] AI samples: {sum(df['label'] == 1)}")
    print(f"[TRAIN_MODEL] Human samples: {sum(df['label'] == 0)}")
    
    return df

def train():
    df = load_and_label_data()
    X = df["clean_text"].values
    y = df["label"].values

    # TF-IDF vectorizer - adjusted for small dataset
    vectorizer = TfidfVectorizer(
        ngram_range=(1, 3),  # Use trigrams for better patterns
        max_features=5000,   # Reduced for small dataset
        min_df=1,            # Include all features due to small dataset
        max_df=0.9,          # Ignore very common words
        sublinear_tf=True    # Use log scaling
    )

    X_vec = vectorizer.fit_transform(X)

    # Use smaller test split due to small dataset
    test_size = min(0.2, 20 / len(y))  # At least 80% training or leave 20 samples for test
    X_train, X_test, y_train, y_test = train_test_split(
        X_vec, y, test_size=test_size, random_state=42, stratify=y
    )

    # Use regularization to prevent overfitting on small dataset
    clf = LogisticRegression(
        max_iter=1000,
        C=1.0,  # Regularization strength
        class_weight='balanced',  # Handle class imbalance
        solver='liblinear'
    )
    clf.fit(X_train, y_train)

    y_pred = clf.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    print(f"[TRAIN_MODEL] Accuracy: {acc:.4f}")
    print("[TRAIN_MODEL] Classification report:")
    print(classification_report(y_test, y_pred))

    # Save model + vectorizer
    joblib.dump(clf, MODELS_DIR / "classifier.pkl")
    joblib.dump(vectorizer, MODELS_DIR / "vectorizer.pkl")
    print("[TRAIN_MODEL] Models saved to backend/models/")

if __name__ == "__main__":
    train()
