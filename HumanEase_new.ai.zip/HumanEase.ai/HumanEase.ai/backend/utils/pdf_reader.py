from typing import Optional
import fitz  # PyMuPDF

def extract_text_from_pdf(file_path: str) -> Optional[str]:
    """
    Extracts text from a PDF file using PyMuPDF.
    """
    try:
        doc = fitz.open(file_path)
        text_chunks = []
        for page in doc:
            text_chunks.append(page.get_text())
        doc.close()
        return "\n".join(text_chunks)
    except Exception as e:
        print(f"[PDF_READER] Error extracting text: {e}")
        return None
