import re

def clean_text(text: str) -> str:
    """
    Basic text cleaning:
    - lowercasing
    - removing extra spaces
    - removing non-alphanumeric symbols (but keep basic punctuation)
    """
    if not text:
        return ""

    # normalize whitespace
    text = text.replace("\n", " ").replace("\r", " ")
    text = re.sub(r"\s+", " ", text)

    # simple cleanup – you can expand for project report
    text = text.strip().lower()

    return text
