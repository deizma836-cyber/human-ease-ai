import google.generativeai as genai
import os

genai.configure(api_key=os.getenv("GEMINI_API_KEY"))

def humanise_text(text, tone):
    try:
        # Create tone-specific instructions
        tone_instructions = {
            "Casual": """
- Write like you're texting a friend
- Use casual words and short sentences
- Add personal touches like "I think", "you know", "honestly"
- Use contractions (don't, can't, I'll, it's)
- Be conversational and relaxed
- Vary sentence length naturally""",
            "Formal": """
- Write in a professional business or academic style
- Use proper grammar and complete sentences
- Maintain clarity and precision
- Write with authority and expertise
- Use varied sentence structures
- Keep tone respectful and measured
- Avoid casual slang but remain readable""",
            "Friendly": """
- Write warmly and engagingly
- Use "you" and "we" to connect with reader
- Add enthusiasm where appropriate
- Keep it upbeat and positive
- Use everyday language
- Be encouraging and supportive"""
        }
        
        tone_guide = tone_instructions.get(tone, tone_instructions["Casual"])
        
        # AI phrases to STRICTLY AVOID (from detector.py)
        ai_blacklist = """
NEVER use these AI-typical phrases:
- moreover, furthermore, additionally, consequently
- it is important to note, it is worth noting, it should be noted
- in conclusion, one must consider, delve into
- cutting-edge, game-changer, revolutionize, paradigm shift
- leverage, facilitate, implementation, comprehensive, robust
- innovative, optimize, enhance, streamline, utilize
- it is essential, it is crucial, landscape, emerged as
- transformative, unprecedented, in today's world, in this day and age
"""
        
        # Adjust rules based on tone
        if tone == "Formal":
            prompt = f"""Rewrite this text in a professional style that MUST score as HUMAN (below 40% AI detection).

CRITICAL: USE THESE HUMAN MARKERS HEAVILY:
- Contractions (use 5-7 minimum): "don't", "can't", "it's", "won't", "I'll", "we're", "that's", "there's", "didn't", "isn't"
- Personal pronouns (use frequently): "I", "we", "my", "our", "me"
- Personal phrases: "I believe", "we see", "I think", "in my view", "I've found", "we can"

EXAMPLE OF HUMAN FORMAL WRITING:
"I think this is important. We can't ignore it. The data shows clear trends, but it's not the whole story. I've found that we need to look deeper. This matters. We're seeing patterns that didn't exist before."

NEVER USE THESE AI WORDS:
- moreover, furthermore, additionally, consequently, thus, hence
- leverage, optimize, paradigm shift, cutting-edge, robust, innovative
- it is important to note, it should be noted, delve into, facilitate

SENTENCE STRUCTURE (CRITICAL):
- Mix very short sentences (4-6 words) with longer ones (15-20 words)
- Example: "This is key. But we can't ignore the broader implications that come with it."
- Avoid uniform sentence lengths - make it feel natural and human

TONE:
- Professional but conversational
- Use active voice
- Write like a human expert talking to a colleague

Text to rewrite:
{text}

Professional human rewrite:"""
        elif tone == "Casual":
            prompt = f"""Rewrite this text like you're explaining it to a friend over coffee. Make it sound COMPLETELY HUMAN.

CRITICAL REQUIREMENTS TO PASS AS HUMAN:
1. AVOID ALL AI BUZZWORDS: {ai_blacklist}
2. Use LOTS of contractions: don't, can't, it's, I'll, you're, we're, that's, there's
3. Add casual markers: "yeah", "honestly", "I think", "you know", "kinda", "pretty much"
4. Use personal pronouns: I, my, me, we, you
5. Vary sentence length wildly - some short. Some longer with natural flow.
6. Be conversational and relaxed
7. Use everyday words, not formal vocabulary
8. Write exactly how you'd text or talk to someone

{tone_guide}

Text to rewrite:
{text}

Casual human rewrite:"""
        else:  # Friendly
            prompt = f"""Rewrite this text in a warm, friendly way that sounds genuinely human.

CRITICAL REQUIREMENTS TO PASS AS HUMAN:
1. AVOID ALL AI BUZZWORDS: {ai_blacklist}
2. Use contractions naturally: it's, don't, can't, you'll, we're, that's
3. Add friendly touches: "you know", "I think", "honestly", "really", "pretty"
4. Use "you" and "we" to connect with reader
5. Mix short and long sentences naturally
6. Be upbeat and encouraging
7. Use everyday language, not formal terms
8. Sound like a helpful friend, not a robot

{tone_guide}

Text to rewrite:
{text}

Friendly human rewrite:"""

        # Configure model for natural output with relaxed safety settings
        from google.generativeai.types import HarmCategory, HarmBlockThreshold
        
        safety_settings = {
            HarmCategory.HARM_CATEGORY_HARASSMENT: HarmBlockThreshold.BLOCK_NONE,
            HarmCategory.HARM_CATEGORY_HATE_SPEECH: HarmBlockThreshold.BLOCK_NONE,
            HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT: HarmBlockThreshold.BLOCK_NONE,
            HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT: HarmBlockThreshold.BLOCK_NONE,
        }
        
        model = genai.GenerativeModel(
            "gemini-2.5-flash",
            safety_settings=safety_settings
        )
        
        generation_config = genai.types.GenerationConfig(
            temperature=0.9,  # Higher creativity for more human-like variation
            top_p=0.95,
            top_k=40,
            max_output_tokens=2048,
        )
        
        response = model.generate_content(prompt, generation_config=generation_config)

        # Check candidates and finish_reason BEFORE accessing response.text
        if not hasattr(response, 'candidates') or not response.candidates:
            print("[HUMANISER ERROR] No candidates in response")
            return "Unable to generate humanized text. Please try again with different input."
        
        candidate = response.candidates[0]
        finish_reason = candidate.finish_reason
        
        # Map finish_reason to user-friendly messages
        # 0 = FINISH_REASON_UNSPECIFIED, 1 = STOP (success), 2 = SAFETY, 3 = RECITATION, 4 = OTHER
        finish_reason_messages = {
            0: "Unable to complete humanization. Please try again.",
            2: "The text couldn't be humanized due to content filters. Try rephrasing your input or using a different tone.",
            3: "The response was blocked due to potential copyright concerns. Please rephrase your text.",
            4: "Unable to generate response. Please try different text or tone."
        }
        
        # Handle non-successful responses
        if finish_reason != 1:  # 1 = STOP (normal completion)
            error_msg = finish_reason_messages.get(finish_reason, "Unable to generate response. Please try again.")
            print(f"[HUMANISER] Response blocked. Finish reason: {finish_reason}")
            return error_msg
        
        # Only access response.text after confirming finish_reason is STOP (1)
        try:
            if hasattr(response, 'text') and response.text:
                return response.text.strip()
        except Exception as text_error:
            print(f"[HUMANISER ERROR] Error accessing response.text: {text_error}")
        
        # Fallback: try to extract text from parts
        if hasattr(candidate, 'content') and hasattr(candidate.content, 'parts'):
            parts_text = ' '.join(part.text for part in candidate.content.parts if hasattr(part, 'text'))
            if parts_text:
                return parts_text.strip()
        
        # If no valid response after all checks
        print(f"[HUMANISER ERROR] No valid text in response. Finish reason: {finish_reason}")
        return "Unable to generate humanized text. Please try again."

    except Exception as e:
        print(f"[HUMANISER ERROR] Exception: {e}")
        return "An error occurred during humanization. Please try again."
