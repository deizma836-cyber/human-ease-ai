from dotenv import load_dotenv
load_dotenv()



import os
from pathlib import Path
import tempfile

from fastapi import FastAPI, Request, UploadFile, File, Form
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from detector import predict_score
from humaniser import humanise_text
from utils.pdf_reader import extract_text_from_pdf
from utils.preprocessing import clean_text

BASE_DIR = Path(__file__).resolve().parent.parent  # HumanEase/
FRONTEND_DIR = BASE_DIR / "frontend"

app = FastAPI(title="HumanEase - AI Content Authenticity Detector & Humaniser")

# Mount static + templates
app.mount(
    "/static",
    StaticFiles(directory=FRONTEND_DIR / "static"),
    name="static"
)
templates = Jinja2Templates(directory=str(FRONTEND_DIR / "templates"))

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/api/detect")
async def detect(
    text: str = Form(None),
    file: UploadFile = File(None)
):
    full_text = text or ""

    # If file uploaded and is PDF, extract text
    if file is not None and file.filename.lower().endswith(".pdf"):
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
            contents = await file.read()
            tmp.write(contents)
            tmp_path = tmp.name
        extracted = extract_text_from_pdf(tmp_path)
        if extracted:
            full_text += "\n" + extracted

    full_text = full_text.strip()
    result = predict_score(full_text)

    return JSONResponse({
        "score": result["score"],
        "label": result["label"],
        "explanation": result["explanation"],
        "textLength": len(full_text)
    })

@app.post("/api/humanise")
async def humanise(payload: dict):
    text = payload.get("text", "")
    tone = payload.get("tone", "Formal")

    if not text.strip():
        return JSONResponse(
            {"error": "No text provided for humanisation."},
            status_code=400
        )

    rewritten = humanise_text(text, tone)

    # Optional: re-run detector on humanised text
    detection_after = predict_score(rewritten)

    return JSONResponse({
        "originalText": text,
        "humanisedText": rewritten,
        "afterScore": detection_after["score"],
        "afterLabel": detection_after["label"],
        "afterExplanation": detection_after["explanation"]
    })
