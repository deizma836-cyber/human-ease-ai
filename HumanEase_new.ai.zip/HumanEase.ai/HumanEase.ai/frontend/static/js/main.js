const analyzeBtn = document.getElementById("analyzeBtn");
const humaniseBtn = document.getElementById("humaniseBtn");

const inputTextEl = document.getElementById("inputText");
const pdfFileEl = document.getElementById("pdfFile");

const scoreBarEl = document.getElementById("scoreBar");
const scoreLabelEl = document.getElementById("scoreLabel");
const scoreTagEl = document.getElementById("scoreTag");
const explanationEl = document.getElementById("explanation");

const originalTextEl = document.getElementById("originalText");
const humanisedTextEl = document.getElementById("humanisedText");
const toneSelectEl = document.getElementById("toneSelect");

const afterScoreLabelEl = document.getElementById("afterScoreLabel");
const afterTagEl = document.getElementById("afterTag");

function setLoading(button, isLoading, textWhenIdle) {
  if (isLoading) {
    button.dataset.prevText = button.textContent;
    button.textContent = "Processing...";
    button.disabled = true;
  } else {
    button.textContent = textWhenIdle || button.dataset.prevText || "Submit";
    button.disabled = false;
  }
}

function updateScoreUI(score, label, explanation) {
  const clamped = Math.max(0, Math.min(100, score || 0));
  scoreBarEl.style.width = clamped + "%";
  scoreLabelEl.textContent = `Score: ${clamped.toFixed(2)} %`;
  explanationEl.textContent = explanation || "";

  let tagText = label || "Uncertain";
  let tagColor = "bg-slate-200 text-slate-600";

  if (label === "Human") {
    tagColor = "bg-emerald-100 text-emerald-700";
  } else if (label === "AI-generated") {
    tagColor = "bg-red-100 text-red-700";
  } else if (label === "Mixed/Uncertain") {
    tagColor = "bg-yellow-100 text-yellow-700";
  }

  scoreTagEl.className =
    "px-2 py-[2px] rounded-full text-[10px] " + tagColor;
  scoreTagEl.textContent = tagText;
}

analyzeBtn.addEventListener("click", async () => {
  try {
    setLoading(analyzeBtn, true, "Analyze");

    const formData = new FormData();
    formData.append("text", inputTextEl.value || "");
    if (pdfFileEl.files.length > 0) {
      formData.append("file", pdfFileEl.files[0]);
    }

    const res = await fetch("/api/detect", {
      method: "POST",
      body: formData,
    });

    if (!res.ok) {
      throw new Error("Detection failed");
    }

    const data = await res.json();
    updateScoreUI(data.score, data.label, data.explanation);

    // Keep the analysed text in original box for humanisation
    originalTextEl.value = inputTextEl.value;
  } catch (err) {
    console.error(err);
    explanationEl.textContent =
      "Something went wrong during detection. Please try again.";
  } finally {
    setLoading(analyzeBtn, false, "Analyze");
  }
});

humaniseBtn.addEventListener("click", async () => {
  try {
    const text = originalTextEl.value || inputTextEl.value;
    const tone = toneSelectEl.value;

    if (!text || text.trim().length === 0) {
      alert("Please analyse or paste text first.");
      return;
    }

    setLoading(humaniseBtn, true, "Humanise Text");

    const res = await fetch("/api/humanise", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ text, tone }),
    });

    if (!res.ok) {
      throw new Error("Humanisation failed");
    }

    const data = await res.json();
    humanisedTextEl.value = data.humanisedText || "";

    const score = data.afterScore;
    const label = data.afterLabel;
    const explanation = data.afterExplanation;

    afterScoreLabelEl.textContent =
      "After score: " + (score != null ? score.toFixed(2) + " %" : "-- %");

    let tagColor = "bg-slate-200 text-slate-600";
    if (label === "Human") {
      tagColor = "bg-emerald-100 text-emerald-700";
    } else if (label === "AI-generated") {
      tagColor = "bg-red-100 text-red-700";
    } else if (label === "Mixed/Uncertain") {
      tagColor = "bg-yellow-100 text-yellow-700";
    }
    afterTagEl.className =
      "px-2 py-[2px] rounded-full text-[10px] " + tagColor;
    afterTagEl.textContent = label || "Uncertain";

    // Also update main meter with new score
    updateScoreUI(score, label, explanation);
  } catch (err) {
    console.error(err);
    alert("Humanisation failed. Check console/logs for details.");
  } finally {
    setLoading(humaniseBtn, false, "Humanise Text");
  }
});
